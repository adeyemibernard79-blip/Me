import java.net.URL
import java.util.zip.ZipInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.nexora.play"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.nexora.play"
        minSdk = 26
        targetSdk = 36
        versionCode = 4
        versionName = "0.2.2"
        ndk { abiFilters += "arm64-v8a" }
    }
    buildTypes {
        release { isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt")) }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    // Emulator cores are loaded by file path, so they must be extracted to disk at install time.
    packaging { jniLibs { useLegacyPackaging = true } }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("com.github.Swordfish90:LibretroDroid:0.13.2")
}

// Downloads the open-source libretro emulator cores (arm64) at BUILD time and packs them into the APK.
// No emulator code or game is shipped in this source project.
val fetchCores by tasks.registering {
    val libDir = layout.projectDirectory.dir("src/main/jniLibs/arm64-v8a").asFile
    val assetDir = layout.projectDirectory.dir("src/main/assets").asFile
    outputs.dir(libDir)
    outputs.dir(assetDir)
    doLast {
        libDir.mkdirs(); assetDir.mkdirs()
        val base = "https://buildbot.libretro.com/nightly/android/latest/arm64-v8a/"
        listOf("ppsspp", "pcsx_rearmed", "desmume").forEach { core ->
            val target = File(libDir, "lib${core}_libretro_android.so")
            if (!target.exists()) {
                URL("$base${core}_libretro_android.so.zip").openStream().use { raw ->
                    ZipInputStream(raw).use { zip ->
                        zip.nextEntry ?: error("Empty core archive for $core")
                        target.outputStream().use { zip.copyTo(it) }
                    }
                }
            }
        }
        // Optional extra core: if it can't be downloaded the build simply goes on without it.
        val optional = File(libDir, "libmelondsds_libretro_android.so")
        if (!optional.exists()) {
            try {
                URL("${base}melondsds_libretro_android.so.zip").openStream().use { raw ->
                    ZipInputStream(raw).use { zip ->
                        zip.nextEntry ?: error("Empty core archive for melondsds")
                        optional.outputStream().use { zip.copyTo(it) }
                    }
                }
            } catch (e: Exception) {
                optional.delete()
                logger.warn("Optional melonDS core not downloaded: ${e.message}")
            }
        }
        val assets = File(assetDir, "PPSSPP.zip")
        if (!assets.exists()) {
            URL("https://buildbot.libretro.com/assets/system/PPSSPP.zip").openStream().use { i ->
                assets.outputStream().use { i.copyTo(it) }
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(fetchCores) }
// Make the ordering explicit for every task that reads the downloaded cores/assets.
tasks.configureEach {
    if (name.startsWith("merge") || name.startsWith("package") || name.startsWith("strip") || name.startsWith("compress")) {
        dependsOn(fetchCores)
    }
}
