# NEXORA PLAY

Android project for NEXORA PLAY.

## Build an APK with GitHub Actions

1. Upload the contents of this folder to the root of a GitHub repository (keep the `.github` folder).
2. Open the repository's **Actions** tab.
3. Select **Build NEXORA PLAY APK** and choose **Run workflow** (or push a commit to `main`).
4. When the run succeeds, open it and download the `NEXORA-PLAY-APK` artifact.
5. Extract the artifact ZIP to find the debug APK.

The workflow installs Android SDK packages, accepts SDK licences non-interactively, and runs the Gradle debug build. The app build also downloads its emulator core files during the build, so the GitHub runner needs internet access.
